package com.zybooks.inventorymanager;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class DetailFragment extends Fragment {

    public static final String ARG_ITEM_ID = "item_id";
    private Item mItem;
    private ItemDatabase db;
    private int item_id;

    public DetailFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        item_id = 1;

        // Get the item ID from the fragment arguments
        Bundle args = getArguments();
        if (args != null) {
            item_id = args.getInt(ARG_ITEM_ID);
        }

        db = new ItemDatabase(this.getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);
        mItem = db.readItem(item_id);

        if (mItem != null) {
            TextView detailHeader = rootView.findViewById(R.id.detail_header);
            detailHeader.setText(mItem.getItemName());

            TextView descriptionTextView = rootView.findViewById(R.id.item_details);
            descriptionTextView.setText(mItem.getItemDescription());
        }

        return rootView;
    }
}