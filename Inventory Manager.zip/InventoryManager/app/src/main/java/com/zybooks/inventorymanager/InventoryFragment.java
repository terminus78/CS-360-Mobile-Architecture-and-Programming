package com.zybooks.inventorymanager;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.app.AlertDialog;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;

public class InventoryFragment extends Fragment {

    private ItemDatabase db;
    private User user;
    private boolean mSMSAllowed = false;
    private SMSPermissionRequest smsDiagBox;
    private final int SMS_ZERO_INVENTORY_PERMISSION = 0;
    private ImageButton zeroInvRequestButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        user = ((InventoryActivity) requireActivity()).user;
        db = new ItemDatabase(this.getContext());
        smsDiagBox = new SMSPermissionRequest();
        //zeroInvRequestButton = this.requireActivity().findViewById(R.id.enable_notifications);
        //zeroInvRequestButton.setOnClickListener(view -> { onRequestSMS(); });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_inventory, container, false);

        // Click listener for the RecyclerView
        View.OnClickListener onClickListener = itemView -> {

            // Create fragment arguments containing the selected band ID
            int selectedItemId = (int) itemView.getTag();
            Bundle args = new Bundle();
            args.putInt(DetailFragment.ARG_ITEM_ID, selectedItemId);

            Navigation.findNavController(itemView).navigate(R.id.show_item_detail, args);
        };

        // Send bands to RecyclerView
        RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
        List<Item> items = db.getAllItems();
        recyclerView.setAdapter(new ItemAdapter(items, onClickListener));
        rootView.findViewById(R.id.add_item_button).setOnClickListener(view -> addItemClick());

        return rootView;
    }

    private void addItemClick() {
        Intent intent = new Intent(this.getContext(), AddItemActivity.class);
        startActivity(intent);
    }

    public void onRequestSMS() {
        // Request sms permission for the device
        if (ActivityCompat.checkSelfPermission(this.getActivity(),
                android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this.getActivity(),
                    android.Manifest.permission.SEND_SMS)) {
                Toast.makeText(this.getActivity(),"Need SMS permission for zero inventory alert", Toast.LENGTH_LONG).show();
            } else {
                ActivityCompat.requestPermissions(this.getActivity(),
                        new String[] {android.Manifest.permission.SEND_SMS},
                        SMS_ZERO_INVENTORY_PERMISSION);
            }
        } else {
            Toast.makeText(this.getContext(),"SMS zero inventory alert is allowed", Toast.LENGTH_LONG).show();
        }
        // Open SMS Alert Dialog
        AlertDialog alertDialog = smsDiagBox.smsDialog(this);
        alertDialog.show();
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItems;
        private final View.OnClickListener mOnClickListener;

        public ItemAdapter(List<Item> items, View.OnClickListener onClickListener) {
            mItems = items;
            mOnClickListener = onClickListener;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            Item item = mItems.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getItemID());
            holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }

    private static class ItemHolder extends RecyclerView.ViewHolder {

        private final TextView mItemNumber;
        private final TextView mItemName;
        private final TextView mItemAmount;
        private final TextView mItemDescription;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.item_inventory, parent, false));
            mItemNumber = itemView.findViewById(R.id.item_number);
            mItemName = itemView.findViewById(R.id.item_name);
            mItemAmount = itemView.findViewById(R.id.item_amount);
            mItemDescription = itemView.findViewById(R.id.item_description);
        }

        public void bind(Item item) {
            mItemNumber.setText(item.getItemID());
            mItemName.setText(item.getItemName());
            mItemAmount.setText(item.getItemAmount());
            mItemDescription.setText(item.getItemDescription());
        }
    }

    public void smsAllowed(boolean isAllowed) {
        mSMSAllowed = isAllowed;
    }
}