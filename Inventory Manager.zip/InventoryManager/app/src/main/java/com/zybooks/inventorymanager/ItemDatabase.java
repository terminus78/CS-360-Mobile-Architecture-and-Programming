package com.zybooks.inventorymanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ItemDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ItemData.db";
    public static final String TABLE_NAME = "ItemTable";
    private static final int VERSION = 1;

    public ItemDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable {
        private static final String COL_ID = "_id";
        private static final String COL_ITEM_NAME = "item_name";
        private static final String COL_AMOUNT = "amount";
        private static final String COL_DESCRIPTION = "description";
    }

    @Override
    public void onCreate (SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_ITEM_NAME + " text, " +
                ItemTable.COL_AMOUNT + " integer, " +
                ItemTable.COL_DESCRIPTION + " text)");
    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(db);
    }

    public void createItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ItemTable.COL_ITEM_NAME, item.getItemName());
        values.put(ItemTable.COL_AMOUNT, item.getItemAmount());
        values.put(ItemTable.COL_DESCRIPTION, item.getItemDescription());

        db.insert(TABLE_NAME, null, values);
    }

    public Item readItem (int id) {
        Item item = new Item();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TABLE_NAME + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(id)});

        if (cursor == null) {
            return item;
        }
        else if (cursor.getCount() != 1) {
            cursor.close();
            return item;
        }

        item.setItemID(cursor.getInt(0));
        item.setItemName(cursor.getString(1));
        item.setItemAmount(cursor.getInt(2));
        item.setItemDescription(cursor.getString(3));
        cursor.close();

        return item;
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ItemTable.COL_ITEM_NAME, item.getItemName());
        values.put(ItemTable.COL_AMOUNT, item.getItemAmount());
        values.put(ItemTable.COL_DESCRIPTION, item.getItemDescription());

        db.update(TABLE_NAME, values,"_id = ?", new String[]{String.valueOf(item.getItemID())});
    }

    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, "_id = ?", new String[]{String.valueOf(id)});
    }

    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TABLE_NAME;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor == null) {
            return itemList;
        }
        else if (cursor.getCount() == 0) {
            cursor.close();
            return itemList;
        }

        do {
            Item item = new Item();
            item.setItemID(cursor.getInt(0));
            item.setItemName(cursor.getString(1));
            item.setItemAmount(cursor.getInt(2));
            item.setItemDescription(cursor.getString(3));
            itemList.add(item);
        } while (cursor.moveToNext());

        cursor.close();
        return itemList;
    }
}
