package com.zybooks.inventorymanager;

import android.app.AlertDialog;
import android.widget.Toast;

public class SMSPermissionRequest {

    public AlertDialog smsDialog(InventoryFragment frag) {
        AlertDialog.Builder builder = new AlertDialog.Builder(frag.getContext());

        builder.setTitle(R.string.sms_dialog_title);
        builder.setIcon(R.drawable.baseline_message_24);
        builder.setCancelable(false);
        builder.setMessage(R.string.sms_dialog_message);
        builder.setPositiveButton(R.string.sms_dialog_allow, (dialog, which) -> {
            Toast.makeText(frag.getContext(), "Zero inventory SMS alerts will now be sent", Toast.LENGTH_LONG).show();
            frag.smsAllowed(true);
            dialog.cancel();
        });
        builder.setNegativeButton(R.string.sms_dialog_deny, (dialog, which) -> {
            Toast.makeText(frag.getContext(),"Zero inventory SMS alerts will not be sent", Toast.LENGTH_LONG).show();
            frag.smsAllowed(false);
            dialog.cancel();
        });

        return builder.create();
    }
}
