package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private EditText mUsernameText;
    private EditText mPasswordText;
    private SQLiteDatabase db;
    private UserDatabase uDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mUsernameText = findViewById(R.id.registerUsernameEntry);
        mPasswordText = findViewById(R.id.registerPasswordEntry);
        uDB = new UserDatabase(this);
    }

    public void onRegister(View view) {
        String username;
        String password;
        Cursor cursor;

        username = mUsernameText.getText().toString().trim();
        password = mPasswordText.getText().toString().trim();

        if (username.isEmpty()) {
            Toast.makeText(this,"Username Empty",Toast.LENGTH_SHORT).show();
        }
        else if (password.isEmpty()) {
            Toast.makeText(this,"Password Empty",Toast.LENGTH_SHORT).show();
        }
        else {
            db = uDB.getReadableDatabase();
            String sql = "select * from " + UserDatabase.TABLE_NAME + " where username = ?";

            try {
                cursor = db.rawQuery(sql, new String[]{username});
            }
            catch (SQLiteException error) {
                User user = new User(username, password);
                uDB.addUser(user);

                Toast.makeText(this,"Registration complete.",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                return;
            }

            if (cursor.getCount() == 0) {
                User user = new User(username, password);
                uDB.addUser(user);
                cursor.close();

                Toast.makeText(this,"Registration complete.",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                return;
            }

            Toast.makeText(this,"User already exists.",Toast.LENGTH_SHORT).show();
            cursor.close();
        }
    }
}