package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {

    private ItemDatabase db;
    private EditText mNewItemName;
    private EditText mNewItemAmount;
    private EditText mNewItemDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        mNewItemName = findViewById(R.id.item_name_edit);
        mNewItemAmount = findViewById(R.id.item_amount_edit);
        mNewItemDescription = findViewById(R.id.item_desc_edit);

        db = new ItemDatabase(this);
    }

    public void onSubmitNewItem(View view) {
        // TODO: Put item into database from verifyNewItem
    }

    private Item verifyNewItem() {
        Item item = new Item();

        if (this.noEmptyItemFields()) {
            item.setItemName(mNewItemName.getText().toString().trim());
            item.setItemAmount(Integer.parseInt(mNewItemAmount.getText().toString().trim()));
            item.setItemDescription(mNewItemDescription.getText().toString().substring(0,32));
        }

        return item;
    }

    private boolean noEmptyItemFields() {
        if (mNewItemName.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Must enter item name", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (mNewItemAmount.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Must enter item amount", Toast.LENGTH_SHORT).show();
            return false;
        }

        int itemAmount = Integer.parseInt(mNewItemAmount.getText().toString().trim());

        if (itemAmount <= 0) {
            Toast.makeText(this, "Item amount must be positive", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (mNewItemDescription.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Must enter item description", Toast.LENGTH_SHORT).show();
            return false;
        }
        else {
            return true;
        }
    }
}