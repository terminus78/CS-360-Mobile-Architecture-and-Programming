package com.zybooks.inventorymanager;

import java.io.Serializable;

public class Item implements Serializable {
    private int mItemID;
    private String mItemName;
    private int mItemAmount;
    private String mItemDescription;

    public Item() {
        mItemID = -1;
        mItemName = "";
        mItemAmount = -1;
        mItemDescription = "";
    }

    public Item(String itemName, int itemAmount, String itemDescription) {
        mItemID = -1;
        mItemName = itemName;
        mItemAmount = itemAmount;
        mItemDescription = itemDescription;
    }

    public Item(int id, String itemName, int itemAmount, String itemDescription) {
        mItemID = id;
        mItemName = itemName;
        mItemAmount = itemAmount;
        mItemDescription = itemDescription;
    }

    public int getItemID() {
        return mItemID;
    }

    public void setItemID(int id) {
        mItemID = id;
    }

    public String getItemName() {
        return mItemName;
    }

    public void setItemName(String itemName) {
        mItemName = itemName;
    }

    public int getItemAmount() {
        return mItemAmount;
    }

    public void setItemAmount(int itemAmount) {
        mItemAmount = itemAmount;
    }

    public String getItemDescription() {
        return mItemDescription;
    }

    public void setItemDescription(String itemDescription) {
        mItemDescription = itemDescription;
    }
}
