package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText mUsernameText;
    private EditText mPasswordText;
    private SQLiteDatabase db;
    private UserDatabase uDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUsernameText = findViewById(R.id.usernameEditText);
        mPasswordText = findViewById(R.id.passwordEditText);
        uDB = new UserDatabase(this);
    }

    public void onLogin(View view) {
        String username;
        String password;
        Cursor cursor;

        username = mUsernameText.getText().toString().trim();
        password = mPasswordText.getText().toString().trim();

        if (username.isEmpty()) {
            Toast.makeText(this,"Username Empty",Toast.LENGTH_SHORT).show();
        }
        else if (password.isEmpty()) {
            Toast.makeText(this,"Password Empty",Toast.LENGTH_SHORT).show();
        }
        else {
            db = uDB.getReadableDatabase();
            String sql = "select * from " + UserDatabase.TABLE_NAME + " where username = ?";

            try {
                cursor = db.rawQuery(sql, new String[]{username});
            }
            catch (SQLiteException error) {
                Log.d("LoginActivity", username);
                Toast.makeText(this,error.toString(),Toast.LENGTH_SHORT).show();
                return;
            }

            if (cursor.getCount() > 1) {
                Toast.makeText(this,"Database corruption. More than 1 matching usernames.",Toast.LENGTH_SHORT).show();
                cursor.close();
                return;
            }

            if (cursor.moveToFirst()) {
                User user = verifyLogin(cursor, password);
                cursor.close();

                Intent intent = new Intent(this, InventoryActivity.class);
                intent.putExtra(InventoryActivity.ONLINE_USER, user);
                startActivity(intent);
            }
            else {
                Toast.makeText(this,"Invalid Username",Toast.LENGTH_SHORT).show();
                cursor.close();
            }
        }
    }

    private User verifyLogin(Cursor cursor, String password) {
        User user = new User();
        String uName = cursor.getString(1);
        String pWord = cursor.getString(2);

        if (password.equals(pWord)) {
            long phoneNum = cursor.getLong(3);
            user.setUsername(uName);
            user.setPassword(pWord);
            user.setPhoneNumber(phoneNum);
        }
        else {
            Toast.makeText(this,"Invalid Password",Toast.LENGTH_SHORT).show();
        }

        return user;
    }

    public void goRegister(View view) {
        // TODO: Implement register navigation
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}